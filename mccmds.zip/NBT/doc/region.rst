.. _module:nbt.region:

:mod:`nbt.region` Module
========================

.. automodule:: nbt.region
    :members:
    :undoc-members:
    :show-inheritance:
