from NBT.nbt import nbt
import sys
import json
import math
from dataclasses import dataclass

def file_check(file):
    if file[-4:] == '.nbt':
        return True
    return False

def size_convert(size):
    total_size = math.prod([tag.value for tag in size])
    return total_size

def propertie_str_conversion(name, value):
    return str(name).strip() + '=' + str(value).strip()

def command_convert(x, y, z, pallete):

    oldBlockHandling = 'replace'

    section_1 = '/setblock'
    section_2 = '~' + str(x+5) + ' ' + '~' + str(y) + ' ' + '~' + str(z+5)
    section_3 = str(pallete['Name'])

    if pallete.get('Properties') is not None:
        section_4 = ','.join(pallete['Properties'])
        return section_1 + ' ' + section_2 + ' ' + section_3 + '[' + section_4 + ']' + ' ' + oldBlockHandling
    return section_1 + ' ' + section_2 + ' ' + section_3 + ' ' + oldBlockHandling

def palette_dict(palette_tags):
    palette_dict, state = {}, 0
    for compounds in palette_tags:
        nested_dict = {}
        for compound in compounds.tags:
            if compound.name == 'Name':
                nested_dict[compound.name] = compound.value
            elif compound.name == 'Properties':
                properties_lst = []
                for propertie in compound.tags:
                    properties_lst.append(propertie_str_conversion(propertie.name, propertie.value))
                nested_dict[compound.name] = properties_lst
            else:
                print("Addition Tag not found (palette): {fname}".format(fname = compound.name))
    
        palette_dict[state] = nested_dict
        state += 1
    
    return palette_dict

def block_dict(block_tags):
    block_dict, cord, block = {}, ['x','y','z'], 1

    for compounds in block_tags:
        nested_dict, cord_index = {}, 0
        for compound in compounds.tags:
            if compound.name == 'pos':
                for pos_tag in compound.tags:
                    nested_dict[str(compound.name) + '_' + cord[cord_index]] = pos_tag.value
                    cord_index += 1
            elif compound.name == 'state':
                nested_dict[compound.name] = compound.value
            else:
                print("Addition Tag not found (blocks): {fname}".format(fname = compound.name))

        block_dict[block] = nested_dict
        block += 1  
          
    return block_dict

def main():
    '''

    '''
    try:
        args = ["file.nbt"]
        FILECK = file_check(args[0])
        if not FILECK:
            print("file not in NBT format")
            return
        str_parse = str(args[0])
        nbtfile = nbt.NBTFile(str_parse,'rb')
    except Exception as error:
       print(error)
       return

    #Total Size Calculation
    size = size_convert(nbtfile['size'].tags)
    
    #Entities Placement
        #To be Worked on

    #blocks Placement
        #Palette Management
    pallette = palette_dict(nbtfile['palette'].tags)
        #Block Management
            #Each Block may contain more then 2 entries - Need to Implement on cases
            #Problem Currently - NBT nested tag
    blocks = block_dict(nbtfile['blocks'].tags)

    #print(type(pallette[1]['Properties'][0]))
    #print(pallette[1]['Properties'][0])

    #print(json.dumps(pallette, indent = 4))
    #print(json.dumps(blocks, indent = 4))
    
    setblock_command_list = []
    for key in blocks:
        #print(key, '->', blocks[key])
        setblock_command = command_convert(blocks[key]['pos_x'], blocks[key]['pos_y'], blocks[key]['pos_z'], pallette[blocks[key]['state']])
        setblock_command_list.append(setblock_command)
    
    print("test")
    return (json.dumps(setblock_command_list, indent = 4))

    #print(json.dumps(setblock_command_list))


    #return


if __name__ == '__main__':
    main()
