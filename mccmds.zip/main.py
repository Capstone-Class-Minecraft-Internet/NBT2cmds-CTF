from pickle import NONE
from NBT.nbt import nbt
import sys
import json
import math
from dataclasses import dataclass
import re


def file_check(file):
    if file[-4:] == '.nbt':
        return True
    return False


def size_convert(size):
    total_size = math.prod([tag.value for tag in size])
    return total_size

def propertie_str_conversion(name, value):
    return str(name).strip() + '=' + str(value).strip()

def command_convert(x, y, z, pallete):

    oldBlockHandling = 'replace'

    section_1 = '/setblock'
    section_2 = '~' + str(x+5) + ' ' + '~' + str(y) + ' ' + '~' + str(z+5)
    section_3 = str(pallete['Name'])

    if pallete.get('Properties') is not None: #if there is properties
        section_4 = ','.join(pallete['Properties'])
        return section_1 + ' ' + section_2 + ' ' + section_3 + '[' + section_4 + ']' + ' ' + oldBlockHandling
    return section_1 + ' ' + section_2 + ' ' + section_3 + ' ' + oldBlockHandling

def naming_command_convert_first(pos, value):
    section_1 = '/minecraft:item replace block '
    section_2 = '~' + str(pos[0]+5) + ' ' + '~' + str(pos[1]) + ' ' + '~' + str(pos[2]+5) + ' '
    section_3 = 'container.' + str(value[0]) + ' '
    section_4 = 'with ' + str(value[1]) + ' '
    section_5 = str(value[2])
    return section_1 + section_2 + section_3 + section_4 + section_5
def naming_command_convert_second(pos, value):
    section_1 = '/minecraft:data modify block '
    section_2 = '~' + str(pos[0]+5) + ' ' + '~' + str(pos[1]) + ' ' + '~' + str(pos[2]+5) + ' '
    section_3 = 'Items[{Slot:' + str(value[0]) + 'b}].tag.display.Name' + ' '
    section_4 = f"""set value '{{"text":"{value[3]}"}}'"""
    return section_1 + section_2 + section_3 + section_4
def palette_dict(palette_tags):
    palette_dict, state = {}, 0
    for compounds in palette_tags:
        nested_dict = {}
        for compound in compounds.tags:
            if compound.name == 'Name':
                nested_dict[compound.name] = compound.value
            elif compound.name == 'Properties':
                properties_lst = []
                for propertie in compound.tags:
                    properties_lst.append(propertie_str_conversion(propertie.name, propertie.value))
                nested_dict[compound.name] = properties_lst
            else:
                continue
                #print("Addition Tag not found (palette): {fname}".format(fname = compound.name))
    
        palette_dict[state] = nested_dict
        state += 1
    
    return palette_dict

def block_dict(block_tags):
    block_dict, cord, block = {}, ['x','y','z'], 1

    for compounds in block_tags:
        nested_dict, cord_index = {}, 0
        for compound in compounds.tags:
            if compound.name == 'pos':
                for pos_tag in compound.tags:
                    nested_dict[str(compound.name) + '_' + cord[cord_index]] = pos_tag.value
                    cord_index += 1
            elif compound.name == 'state':
                nested_dict[compound.name] = compound.value
            else:
                continue
                #print("Addition Tag not found (blocks): {fname}".format(fname = compound.name))

        block_dict[block] = nested_dict
        block += 1  

    #print(type(block_dict))

    #print(block_dict)

    sorted_dict = dict(sorted(block_dict.items(), key=lambda x: x[1]['pos_y']))
          
    return sorted_dict
def container_dict(block_tags):
    nest_list = []
    for compounds in block_tags:
        pos = []
        for compound in compounds.tags:
            if compound.name == 'pos':
                for pos_tag in compound.tags:
                    pos.append(pos_tag.value)
            elif compound.name == 'nbt':
                for item_tag in compound.tags:
                    if item_tag.name == 'Items' and item_tag.tags != []:# there is stuff in this block position (blocks that can store things)
                        for item_compound in item_tag.tags:
                            list = [0]
                            nbt = []
                            nbt.append(str(item_compound['Slot']))
                            nbt.append(str(item_compound['id']))
                            nbt.append(str(item_compound['Count']))
                            try:
                                for tags in item_compound['tag'].tags:
                                    if tags.name == 'display':
                                        pattern = r'"text":"(.*?)"'
                                        match = re.search(pattern, tags['Name'].tag_info())
                                        if match:
                                            result = match.group(1)
                                            nbt.append(str(result))
                                        else:
                                            print("No match found")
                                
                                list.append(pos)
                                list.append(nbt)
                                nbt.append(0)
                                nest_list.append(list)
                            except:
                                nbt.append(0)
                                list.append(pos)
                                list.append(nbt)
                                nest_list.append(list)
    command_list = []
    for value in nest_list:
        command1 = naming_command_convert_first(value[1], value[2])
        command_list.append(command1)
        if value[2][3] != 0:
            command2 = naming_command_convert_second(value[1], value[2])
            command_list.append(command2)
    return command_list

def entity_command_convert(entity_name, entity_Pos, entity_dictionary):

    summon = "/summon"

    pos = '~' + str(int(entity_Pos[0]+5)) + ' ' + '~' + str(entity_Pos[1]) + ' ' + '~' + str(int(entity_Pos[2]+5))
    
    output_list = []
    for key, value in entity_dictionary.items():
        if key == "CustomName":
            value = f"\"{value}\""
        output_list.append(f"{key}:{value}")

    output_string = ", ".join(output_list)
    wrapped_string = f"{{{output_string}}}"

    #print(output_string)
    if wrapped_string == "{}":
        merged_string = " ".join([summon, entity_name, pos])
    else:
        merged_string = " ".join([summon, entity_name, pos, wrapped_string])

    #print(merged_string)
    return merged_string
    
def entities_lst(entities_tag):

    commands = []

    for compounds in entities_tag:
        #print(compounds)
        entity_name = ""
        entity_Pos = []
        entity_dictionary = {}
        for compound in compounds.tags: #nbt tags and each entity pos and blockPos
            #print(compound)
            if compound.name == 'nbt':
                #print(compound.name)
                for nbt in compound.tags:

                    if nbt.name == 'CustomName': #only implementing name tags
                        string = nbt.value
                        match = re.search(r'{"text":"(.+?)"}', string)
                        if match:
                            tag = match.group(1)
                            entity_dictionary["CustomName"] = tag

                    if nbt.name == 'IsBaby':
                        entity_dictionary["IsBaby"] = nbt.value
                    if nbt.name == 'Facing':
                        entity_dictionary["Facing"] = nbt.value
                    
                    if nbt.name == 'id': #id is store seperately for modding
                        entity_name = nbt.value


            if compound.name == 'blockPos':
                for pos in compound:
                    entity_Pos.append(pos.value)
            if compound.name == 'pos':
                continue
        
        #print(entity_name)
        #print(entity_Pos)
        #print(entity_dictionary)

        command = entity_command_convert(entity_name, entity_Pos, entity_dictionary)

        commands.append(command)

    return commands

def main():
    '''

    '''
    try:
        args = ["file.nbt"]
        FILECK = file_check(args[0])
        if not FILECK:
            print("file not in NBT format")
            return
        str_parse = str(args[0])
        print("loading ")
        nbtfile = nbt.NBTFile(str_parse,'rb')
        print("finished loading")
    except Exception as error:
       print(error)
       return

    #Total Size Calculation
    size = size_convert(nbtfile['size'].tags)
    print("size")
    
    #Entities Placement
    entities = entities_lst(nbtfile['entities'].tags)
    print("entities")

    #blocks Placement
        #Palette Management
    pallette = palette_dict(nbtfile['palette'].tags)
        #Block Management
            #Each Block may contain more then 2 entries - Need to Implement on cases
            #Problem Currently - NBT nested tag
    blocks = block_dict(nbtfile['blocks'].tags)

    container = container_dict(nbtfile['blocks'].tags)
    #print(type(pallette[1]['Properties'][0]))
    #print(pallette[1]['Properties'][0])

    #print(json.dumps(pallette, indent = 4))
    #print(json.dumps(blocks, indent = 4))
    
    setblock_command_list = []
    entities_command_list = []
    print("start convert")

    #block convertion
    for key in blocks:
        #print(key, '->', blocks[key])
        if pallette[blocks[key]['state']]['Name'] == 'minecraft:air':
            continue
        setblock_command = command_convert(blocks[key]['pos_x'], blocks[key]['pos_y'], blocks[key]['pos_z'], pallette[blocks[key]['state']])
        setblock_command_list.append(setblock_command)

    print("done convert")
    #entity conversion (Mainly for checking priorty)

    pattern = r"minecraft:(\w+)"
    for entitie in entities:
        match = re.search(pattern, entitie)
        if match.group(1) == 'item':
            continue
        entities_command_list.append(entitie)


    full_command_list = setblock_command_list + entities_command_list + container
    print("start dump")
    return json.dumps(full_command_list, indent = 4)
    
    """
    #Printing blocks command
    print(json.dumps(setblock_command_list, indent = 4))
    #printing entities command
    print(json.dumps(entities_command_list, indent = 4))
    """


if __name__ == '__main__':
    main()
